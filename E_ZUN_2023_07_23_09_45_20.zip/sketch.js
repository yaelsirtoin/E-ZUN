let canvasWidth, canvasHeight;
let bgColor;
let logoImg;
let countdownDate = new Date("2024-08-13T00:00:00").getTime(); // August 13, 2024 00:00:00
let countdownString = ""; // Store the countdown string
let soundLoop;

function preload() {
  // Load the image before the sketch starts
  logoImg = loadImage("LOGO.png");

  // Load the sound and set it to loop
  soundFormats("mp3");
  soundLoop = loadSound("SOUND.mp3");
}

function setup() {
  // Set A4 proportions (21cm x 29.7cm)
  canvasWidth = 21 * 72; // Convert cm to pixels (assuming 1 inch = 72 pixels)
  canvasHeight = 29.7 * 72;

  // Create canvas with A4 proportions
  createCanvas(canvasWidth, canvasHeight);

  // Generate a random background color
  generateRandomBackground();

  // Initial countdown display
  updateCountdown();
}

function draw() {
  // Draw the background with random ellipses
  for (let i = 0; i < 100; i++) {
    let x = random(width);
    let y = random(height);
    let size = random(1, 5);
    let alpha = random(100, 200);
    fill(255, alpha);
    noStroke();
    ellipse(x, y, size, size);
  }

  // Draw the logo in the center of the canvas
  if (logoImg) {
    let logoWidth = min(width * 0.8, height * 0.8); // Limit the logo size to 80% of the canvas dimensions
    let logoHeight = (logoWidth * logoImg.height) / logoImg.width;
    image(
      logoImg,
      (width - logoWidth) / 2,
      (height - logoHeight) / 2,
      logoWidth,
      logoHeight
    );
  }

  // Check if the sound is loaded and play it in loops
  if (soundLoop.isLoaded() && !soundLoop.isPlaying()) {
    soundLoop.loop();
  }
}

function mouseClicked() {
  // When the mouse is clicked, generate a new random background color and update the countdown
  generateRandomBackground();
  updateCountdown();
}

function generateRandomBackground() {
  // Generate a random color for the background
  let r = random(255);
  let g = random(255);
  let b = random(255);
  bgColor = color(r, g, b);
  background(bgColor);
}

function updateCountdown() {
  // Calculate and update the countdown
  let now = new Date().getTime();
  let distance = countdownDate - now;

  if (distance < 0) {
    // Countdown date has passed, reset the countdown to the original date
    countdownDate = new Date("2024-08-13T00:00:00").getTime();
    distance = countdownDate - now; // Recalculate the distance
  }

  let days = Math.floor(distance / (1000 * 60 * 60 * 24));
  let hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  let minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  let seconds = Math.floor((distance % (1000 * 60)) / 1000);

  // Clear the previous countdown display by drawing a rectangle over it
  fill(bgColor);
  noStroke();
  rect(width / 2 - 150, height - 40, 300, 40);

  // Store the new countdown string
  countdownString = `Countdown: ${days}d ${hours}h ${minutes}m ${seconds}s until 08/13/2024`;

  // Display the new countdown with increased font size and at the bottom of the canvas
  fill(0); // Set text color to black
  textAlign(CENTER);
  textSize(50); // Increase the font size
  textStyle(BOLD); // Set the text style to bold
  text(countdownString, width / 2, height - 200); // Position the countdown 50 pixels above the bottom of the canvas
}

function keyPressed() {
  // Save the canvas as a PNG image when the "S" key is pressed
  if (key === "S") {
    saveCanvas("my_canvas", "png");
  }
}
